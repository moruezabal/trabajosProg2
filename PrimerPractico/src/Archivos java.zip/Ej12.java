
public class Ej12 {

	public static void main(String[] args) {

		int n = 4;	// cantidad de filas
		int m = 5;	//cantidad de columnas
		int aux=0;  // Auxiliar

		int mat[][]=new int [n][m];
		
		cargar_matriz(mat, 10);
		imprimir_matriz(mat); 
		
		//ordenamos la matriz de menor a mayor de la siguiente manera
		for( int i=0; i < n; i++){ //iterador de la fila del elemento a comparar
			for( int j=0;j< m; j++){ // iterador de la columna del elemento a comparar
				for(int x=0; x < n; x++){ // iterador de la fila del elemento con el que lo comparamos
					for(int y=0; y <m; y++){ // iterador de la columna del elemento con el que lo comparamos
						if(mat[x][y] > mat[i][j]){ // Si la celda a comparar es mayor a la del que lo comparamos
							//Hacemos el cambio de valores entre celdas con la ayuda de un auxiliar
							aux = mat[i][j];
							mat[i][j] = mat[x][y];
							mat[x][y] = aux;

						}
					}
				}
			}
		}
		
		System.out.println("");
		imprimir_matriz(mat);
		
	}
	
	public static void cargar_matriz (int [] [] mat, int max) {
		for (int i = 0; i<mat.length ;i++) {
			for (int j = 0; j<mat[i].length;j++) {
				mat [i] [j] = (int) (Math.random()* max);
			}
		}
	}
	
	private static void imprimir_matriz (int [] [] mat) {

		for ( int i = 0; i<mat.length; i++) {
			for(int j = 0; j<mat[i].length;j++) {
				System.out.print(" "+mat [i] [j]);
			}
			System.out.println("");
		}
	}
}

